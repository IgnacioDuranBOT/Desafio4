import numpy as np
from util import read_data, pre_proc, split_data, Sigmoid, MSE

data_path = "data/dataset.csv"

class capa_neuronal():
  """ parametros de entrada:
      n_conn = numero de conexiones con la capa anterior
      n_neur = numero de neuronas que tendra esta capa
      act_f = funcion de activacion que tendra esta capa
  """ 
  def __init__(self, n_conn, n_neur, act_f):
    self.act_f = act_f
    """ vector columna con numero de bias, el cual coincide con el numero de neuronas
        el cual partira con valores al azar de -1 a 1
    """
    self.b = np.random.rand(1, n_neur) * 2 - 1
    """ matriz con los pesos asociados entre la capa anterior y esta
    """
    self.w = np.random.rand(n_conn, n_neur) * 2 - 1

def crear_red(topologia, act_f):
    nn = []
    for l, layer in enumerate(topologia[:-1]):
        nn.append(capa_neuronal(topologia[l], topologia[l + 1 ], act_f))
    return nn



def predict(neuronal_net, entrada):
    '''
        recorre las capas
        realizando el producto punto entre el vector
        de entrada y los pesos de la capa.
    '''
    
    out = [(None, entrada)]
    # forward pass
    for index, layer in enumerate(neuronal_net):

        suma_ponderada = out[-1][1] @ neuronal_net[index].w + neuronal_net[index].b
        # activacion
        activacion = neuronal_net[0].act_f.activation(suma_ponderada)
        # se guarda como tupla los valores de la suma ponderada y la activacion
        out.append((suma_ponderada, activacion))
    return out


def entrenamiento(neuronal_net, entrada, salida, l2_cost, learning_rate, epocas):


    # Entrenamos la red i epocas
    for i in range(epocas):

        out = [(None, entrada)]
        # forward pass
        for index, layer in enumerate(neuronal_net):

            suma_ponderada = out[-1][1] @ neuronal_net[index].w + neuronal_net[index].b
            # activacion
            activacion = neuronal_net[0].act_f.activation(suma_ponderada)
            # se guarda como tupla los valores de la suma ponderada y la activacion
            out.append((suma_ponderada, activacion))

        # backward
        deltas = []
        for index in reversed(range(0, len(neuronal_net))):
            """ accedemos a index + 1 porque que la red neuronal no contiene la capa de entrada a diferencia de out,
                por lo que su indice esta desfasado en 1
            """
            suma_ponderada = out[index + 1][0]
            activacion = out[index + 1][1]
            # ultima capa
            if index == len(neuronal_net) - 1:
                deltas.insert(0, l2_cost(activacion, salida) * neuronal_net[index].act_f.activation_derivated(activacion))
            else:
                deltas.insert(0, deltas[0] @ _w.T * neuronal_net[index].act_f.activation_derivated(activacion))

            _w = neuronal_net[index].w

            # gradient descent
            neuronal_net[index].b = neuronal_net[index].b - np.mean(deltas[0], axis=0, keepdims=True) * learning_rate
            neuronal_net[index].w = neuronal_net[index].w - out[index][1].T @ deltas[0] * learning_rate


def test(neuronal_net, entrada, salida):
    contador = 0
    for index, d in enumerate(entrada):
        predicted_value = predict(neuronal_net, d)[-1][1]
        if np.rint(predicted_value)[0] == salida[index][0]:
            contador += 1
    return contador / len(entrada)


if __name__ == '__main__':
    """ se lee el dataset y se pre procesa"""
    unwanted_cols = ['song_title', 'artist', 'duration_ms', 'key', 'mode', 'popularity', 'time_signature']
    salida_columns = [-1]
    data, headers = read_data(data_path, unwanted_cols)
    print(headers)
    input('Enter para continuar...')
    training_data, test_data = pre_proc(data, 70)
    entrada, salida = split_data(training_data, salida_columns)
    entrada_test, salida_test = split_data(test_data, salida_columns)

    topology = [entrada[0].size, 10, 8, salida[0].size]
    epochs = 600
    learning_rate = 0.07
    """Topology es una lista con la cantida de neuronas en cada capa
        act_f es la funcion de activacion que sera usada por cada capa """

    print('Creando red neuronal de topologia: ', topology)
    nn = crear_red(topology, Sigmoid)

    print('Iniciando entrenamiento...')
    entrenamiento(nn, entrada, salida, MSE.derivated_loss, learning_rate, epochs)
    print('Entrenamiento finalizado.')

    print('Iniciando testing...')
    accuracity = test(nn, entrada_test, salida_test)
    print('Accuracity: ', accuracity)



